package com.cg.trust.exception;

public class TrustException extends Exception{
	private static final long serialVersionUID = 1309018903004122308L;

	public TrustException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrustException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
