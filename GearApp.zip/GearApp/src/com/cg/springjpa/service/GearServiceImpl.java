package com.cg.springjpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.cg.springjpa.dao.GearDao;
import com.cg.springjpa.dto.Gear;

@Service
@Transactional
public class GearServiceImpl implements GearService{

	
	@Autowired
	GearDao dao;
	
	
	@Override
	public Gear fetchRecord(Gear id) {
		// TODO Auto-generated method stub
		return dao.fetchRecord(id);
	}

	@Override
	public int updateRecord(Gear record) {
		// TODO Auto-generated method stub
		return dao.updateRecord(record);
	}

}
