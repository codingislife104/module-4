package com.cg.springjpa.service;

import com.cg.springjpa.dto.Gear;



public interface GearService {
	Gear fetchRecord(Gear id);

	public int updateRecord(Gear record);
}
