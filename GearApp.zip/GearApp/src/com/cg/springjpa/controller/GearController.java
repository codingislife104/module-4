package com.cg.springjpa.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;







import com.cg.springjpa.dto.Gear;
import com.cg.springjpa.service.GearService;



@Controller
public class GearController {
	@Autowired
	GearService service;
	
	@RequestMapping("/modifyTrainee")
	public String modifyShow(Model model)
	{
		Gear gear = new Gear();
		model.addAttribute("id", gear);
		return "modify";
	}
	@RequestMapping("/modifyGear")
	public String fetchrecord(@ModelAttribute ("id") Gear id,Model model)
	{
		Gear record = service.fetchRecord(id);
		model.addAttribute("record", record);
	
			return "modify1";
		
	}
	
	@ModelAttribute("smeList")
	public Map<String,String> getSmeList(){
		Map<String,String> smeList=new HashMap<String,String>();
		smeList.put("Uma", "Uma");
		smeList.put("Rahul", "Rahul");
		smeList.put("Kavita", "Kavita");
		smeList.put("Hema", "Hema");
		return smeList;
		
	}
	@RequestMapping("/updateDetails")
	public String updateDetails(@Valid @ModelAttribute ("record")Gear record,BindingResult result,Model model)
	{
		int id=service.updateRecord(record);
		if(result.hasErrors())
		{
		return "modify1";
		
		}
		else
		{
			if(id!=0)
			{
				model.addAttribute("queryId", id);
				return "success" ;
			}
			else
			{
				return "error";
			}
		}
		
	}

}
