package com.cg.springjpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.cg.springjpa.dto.Gear;

@Repository
public class GearDaoImpl implements GearDao{

	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public Gear fetchRecord(Gear id) {
		Gear gear = em.find(Gear.class, id.getQueryId());
		return gear;
	}

	@Override
	public int updateRecord(Gear record) {
		em.merge(record);
		em.flush();
		return record.getQueryId();
		
	}

}
