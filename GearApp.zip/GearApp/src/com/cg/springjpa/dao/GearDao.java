package com.cg.springjpa.dao;

import com.cg.springjpa.dto.Gear;

public interface GearDao {
	Gear fetchRecord(Gear id);

	public int updateRecord(Gear record);
}
