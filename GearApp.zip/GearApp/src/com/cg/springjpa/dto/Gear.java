package com.cg.springjpa.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;



@Entity
@Table(name="query_master")
public class Gear implements Serializable{
	
	
	@Id
	@Column(name="query_id")
	private int queryId;
	private String technology;
	private String query_raised_by; 
	private String query;
	
	@NotNull(message="Solution field Should not kept blank")
	@Pattern(regexp="^[a-z]$",message="last name should start with capital")
	private String solutions;
	
	@NotNull(message="You must select one of the name")
	private String solution_given_by;
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQuery_raised_by() {
		return query_raised_by;
	}
	public void setQuery_raised_by(String query_raised_by) {
		this.query_raised_by = query_raised_by;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolution_given_by() {
		return solution_given_by;
	}
	public void setSolution_given_by(String solution_given_by) {
		this.solution_given_by = solution_given_by;
	}
}
