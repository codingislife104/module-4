package com.cg.product.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.product.dao.ProductDAO;
import com.cg.product.dto.Product;
@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDAO dao;
	@Override
	public ArrayList<Product> viewProductList() {
		
		return dao.viewProductList();
	}

	@Override
	public int deleteProductDetails(Product product) {
		
		return dao.deleteProductDetails(product);
	}

}
