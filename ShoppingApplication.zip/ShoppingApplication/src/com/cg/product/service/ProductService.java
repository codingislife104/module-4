package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.dto.Product;

public interface ProductService {
	public ArrayList<Product>viewProductList();
	public int deleteProductDetails(Product product);
}
