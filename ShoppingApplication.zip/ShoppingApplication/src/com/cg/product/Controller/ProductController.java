package com.cg.product.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



import org.springframework.web.bind.annotation.RequestParam;

import com.cg.product.dto.Product;
import com.cg.product.service.ProductService;


@Controller
public class ProductController {
	@Autowired
	ProductService service;
	@RequestMapping("/homepage")
	
	public String displayProductList(Model model){
		
		ArrayList<Product> list=service.viewProductList();
		model.addAttribute("ProductList",list);
		return "ViewProduct";
	}
	@RequestMapping("/deleteProduct")
	public String deleteProductList(Model model,@RequestParam("id") int id)
	{
		Product product = new Product();
		product.setProductId(id);
		service.deleteProductDetails(product);
		ArrayList<Product> list=service.viewProductList();
		model.addAttribute("ProductList",list);
		return "ViewProduct";
		
		
	}
}
