package com.cg.product.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;
@Repository
public class ProductDAOImpl implements ProductDAO {
	@PersistenceContext
	EntityManager em;
	@Override
	public ArrayList<Product> viewProductList() {
		
		ArrayList<Product> list;
		String query= "select p from Product p ";
		TypedQuery<Product> qry= em.createQuery(query,Product.class);
		list=(ArrayList<Product>) qry.getResultList();
		return list;
	}

	@Override
	public int deleteProductDetails(Product product) {
		
		product=em.find(Product.class, product.getProductId());
		
		
		if(product!=null)
		{
		em.remove(product);
		}
		else
			return 0;
		em.flush();
		return product.getProductId();
	}

	

}
