package com.cg.product.dao;

import java.util.ArrayList;

import com.cg.product.dto.Product;



public interface ProductDAO {

	public ArrayList<Product>viewProductList();
	public int deleteProductDetails(Product product);
}
